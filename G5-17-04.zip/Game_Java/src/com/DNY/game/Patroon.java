package com.DNY.game;

import java.awt.Graphics;
import java.awt.Image;
import java.util.Random;

import javax.swing.ImageIcon;

public class Patroon {
	
	ImageIcon icon_patroon;
	Image patroon;
	
	final int X = 30;
	final int Y = 46;
	
	Random random;
	
	public int[] y_coord_patronen;
	
	public int xpa;
	public int ypa;
	
	public Patroon() {
		
		this.icon_patroon = new ImageIcon(getClass().getResource("/Images/patroon.png"));
		this.patroon = icon_patroon.getImage();
		
		this.random = new Random();
		
		y_coord_patronen = new int[Rots.AANTAL_ROTSEN/2];
		
		xpa = Main.WIDTH +( (Rots.X_ROTS_BEELD/2) - this.X/2);    // !!de positie van de eerste patroon is afankelijk van de positie van de eerste rots (zie classe rots)!!!!!!!!!!!
		
	}
	
	
	//methode om de y-coordinaten van de patronen te bepalen
	public void y_coordinaten(int[][] lijst) {
		
		for(int i =0; i < lijst.length ; i+=2){
			y_coord_patronen[i/2] = random.nextInt(lijst[i][1] + Rots.Y_ROTS_BEELD , lijst[i][0] - this.Y);
		}

	}
	
	public int n = 0;
	public void draw(Graphics g) {
		this.ypa = this.y_coord_patronen[n];
		g.drawImage(this.patroon, xpa , ypa, null);
	}
	
	
	

}
