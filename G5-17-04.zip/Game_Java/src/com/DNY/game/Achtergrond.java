package com.DNY.game;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class Achtergrond {
	
	ImageIcon icon_achtergrond;
	Image achtergrond;
	final int BREEDTE_ACHTEGROND = 1697;     			//de werkelijke breedte van de achtergrond (zelf zoeken bij propreties van het beeld)
	
	public int x1=0;       								//X-positie van het achtergrond moet public want in andere classen geroept
	public int x2= BREEDTE_ACHTEGROND + 1;				//x1 is de x-positie van het eerste beeld en x2 is de x-positie van het 2de beeld (jwz waarom je een +1 heb gedaan, denk terug na)
	
	//hier uploaden we het beeld
	public Achtergrond(){
		this.icon_achtergrond = new ImageIcon(getClass().getResource("/Images/achtergrond.png"));
		this.achtergrond = this.icon_achtergrond.getImage();	
	}
	
	
	public void draw(Graphics g) {                 		//deze methode tekent de achtergrond  (en gaat vervolgens telkens opgeroepen worden)
		g.drawImage(this.achtergrond, x1 ,0, null);
		g.drawImage(this.achtergrond, x2 ,0, null);
		
	}
}

