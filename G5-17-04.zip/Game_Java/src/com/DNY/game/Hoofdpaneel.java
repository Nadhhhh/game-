package com.DNY.game;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.lang.reflect.Array;
import java.text.DateFormat.Field;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JPanel;



public class Hoofdpaneel extends JPanel implements KeyListener {
	
	
	final int v1 = 2;      											//EXECUTIE-snelheid in miliseconde
	Achtergrond background;
	Ufo ufo;
	Rots rots;
	Patroon patroon;
	
	ArrayList<Kogel> lijst_kogels;
	
	ArrayList<Projectiel> lijst_projectielen;
	int index = 0;
	
	
	
	
	
	
	public Hoofdpaneel() {
		
		background = new Achtergrond();
		ufo = new Ufo();
		rots = new Rots();
		
		patroon = new Patroon();
		patroon.y_coordinaten(rots.y_coord_rotsen);
		
		lijst_kogels = new ArrayList<Kogel>();
		
		lijst_projectielen = new ArrayList<Projectiel>();
		for (int k = 0; k<1000; k++) {
			lijst_projectielen.add(new Projectiel());
		}


		
		
		Timer t = new Timer();										//t is gewoon een timer, het meet de tijd
		t.scheduleAtFixedRate(new UpdateTimerTask(), 0, v1);	 	// deze functie zorgt ervoor dat taken worden uitgevord taak=updatetimertask, elke v1 mseconde is er een verandering, en begint met een verandering van 0ms(delay)
	
	} 
	
	
	@Override           											//override staat er omdat we nu een functie herdefinieren met van het tekenen van de achtergrond die we in de classe 'achtergrond' hebben gemaakt
	public void paintComponent(Graphics g) {						//DIT MOET OMDAT WE REPAINT GEBRUIKEN EN REPAINT GAAT ENKEL PAINTCOMPONENT OPROEPEN, de functie in de classe 'achtergrond' niet!!
		background.draw(g);
		rots.draw(g);
		patroon.draw(g);
		ufo.draw(g);
		
		
		for(int m=0;m <this.lijst_kogels.size();m++) {
			lijst_kogels.get(m).draw(g);
		}
		/*
		for (int k=0; k<1000; k++) {
			lijst_projectielen.get(k).draw(g);
			
		}
		*/
	}
	
	
	public class UpdateTimerTask extends TimerTask{        			//dit is de 'taak' dat elke v1 miliseconde opgeroepen wordt hierboven. taak = de x positie telkens verlagen EN HERTEKENEN met repaint
															
		@Override
		public void run() {
			     													
			background.x1 -=1 ;
			background.x2 -=1;
			
			if(background.x1 <= -(background.BREEDTE_ACHTEGROND + 1)) {
				background.x1 = background.BREEDTE_ACHTEGROND +1 ;
			}
			if(background.x2 <= -(background.BREEDTE_ACHTEGROND + 1)) {
				background.x2 = background.BREEDTE_ACHTEGROND + 1;
			}
		    
			
			patroon.xpa-=2;
			
			if(patroon.xpa<=-patroon.X) {
				patroon.n+=1;
				patroon.xpa = (rots.X_ROTS_BEELD/2) - (patroon.X/2) + rots.X_AFSTAND +rots.X_ROTS_BEELD + rots.X_AFSTAND + ( (Rots.X_ROTS_BEELD/2) - patroon.X/2);
			}
			
			if(patroon.xpa - ufo.X <= ufo.XU && ufo.XU<= patroon.xpa + patroon.X       &&      patroon.ypa-ufo.Y <=ufo.yu && ufo.yu <= patroon.ypa+patroon.Y) {
				patroon.ypa=-patroon.Y;
			}
			
			
			
			
			rots.x1 -=2;
			rots.x2 -=2;
			
			if(rots.x1<=-rots.X_ROTS_BEELD & rots.j < rots.AANTAL_ROTSEN-5) {
				rots.j+=2;
				rots.x1= rots.X_AFSTAND + rots.X_ROTS_BEELD + rots.X_AFSTAND;
				
			}
			
			if(rots.x2<=-rots.X_ROTS_BEELD & rots.k < rots.AANTAL_ROTSEN-5){
				rots.k+=2;
				rots.x2= rots.X_AFSTAND + rots.X_ROTS_BEELD + rots.X_AFSTAND;
				
			}
			
			
			
			for(int m=0;m <lijst_kogels.size();m++) {
				lijst_kogels.get(m).xk+=2;
			}
			
			if(index == 0) {
				lijst_projectielen.get(index).xk -=3;
				index +=1;}
			else if (index >= 1 && lijst_projectielen.get(index-1).xk<= (Main.WIDTH)/2*0.75 && index<=lijst_projectielen.size()) {
				lijst_projectielen.get(index).xk -=3;
				lijst_projectielen.get(index-1).xk-=3;
			}
			else{
				lijst_projectielen.get(index-1).xk -=3;
			}
			
			if(lijst_projectielen.get(index).xk <= (Main.WIDTH)/2*0.75) {
				index += 1;
			}
			
			
			
			Rectangle r_patroon = new Rectangle(patroon.xpa, patroon.ypa,patroon.X,patroon.Y);
			Rectangle r_ufo = new Rectangle(ufo.XU, ufo.yu,ufo.X,ufo.Y);
			
			if(r_ufo.intersects(r_patroon)==true ) {
				System.exit(0);
				System.out.println("hello");
				
			}
			 
			repaint(); 												//na het maken van de taak,  wordt het beeld hertekend met 'repaint', repaint roept 'PAINTCOMPONENT'aan !!!!!!
		}
		
		
	}

	
	
	
	@Override
	public void keyTyped(KeyEvent e) {
		
		
	}

	private double interpolationFactor = 200;

	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode()==KeyEvent.VK_UP & ufo.yu > 0) {
			ufo.yu -= 30;
			
		}else if(e.getKeyCode()==KeyEvent.VK_DOWN &  ufo.yu < Main.HEIGHT - ufo.Y ) {
			ufo.yu += 30;
		} 	
		
		
	}

	


	@Override
	public void keyReleased(KeyEvent e) {
		if(e.getKeyCode()==KeyEvent.VK_SPACE){
			Kogel kogel = new Kogel(ufo);
			this.lijst_kogels.add(kogel);
		}
		
	}
	




	

	
	
	
	
}

