package com.DNY.game;

import java.awt.Graphics;
import java.awt.Image;
import java.util.Random;

import javax.swing.ImageIcon;

public class Projectiel {
	
	ImageIcon icon_projectiel;
	Image projectiel;
	
	final int X;
	final int Y;
	
	float xk;
	float yk;
	
	
	
	
	public Projectiel() {
		
		this.icon_projectiel = new ImageIcon(getClass().getResource("/Images/projectiel.png"));
		this.projectiel = this.icon_projectiel.getImage();
		
		Random rng = new Random();
		
		this.X = 100;
		this.Y = 96;
		
		this.xk = Main.WIDTH;
		this.yk = rng.nextInt(Main.HEIGHT);
			
	}
	
	public void draw(Graphics g) {
		g.drawImage(this.projectiel, (int)this.xk, (int)this.yk, null);
		
	}
	
	
	

}
