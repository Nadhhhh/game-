package com.DNY.game;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;


public class Ufo{
	
	ImageIcon icon_ufo;
	Image ufo;
	
	public final int X ;    				//Breedte van het upgeloadde beeld (ufo)
	public final int Y ;	 				//Lengte van het upgeloadde beeld (ufo)
	
	public final int XU  ; 					//XU is de x-positie van de UFO			Deze berekening zorgt ervoor dat beeld per default perfect in 1/5 van de x-As zit (op x-as gaat de ufo nooit veranderen dus 'final')
	public int yu ; 						//XU is de y-positie van de UFO			Deze berekening zorgt ervoor dat beeld per default perfect in het midden van de y-As zit 
	
	
	public Ufo() {
		this.icon_ufo = new ImageIcon(getClass().getResource("/Images/UFO.png"));
		this.ufo = this.icon_ufo.getImage();
		
		this.X = 137;
		this.Y = 70;
		
		this.XU = Main.WIDTH/5 - this.X/2  ;
		this.yu = Main.HEIGHT/2 - this.Y/2;
	}
	
	
	
	public void draw(Graphics g) {
		g.drawImage(this.ufo, XU, yu , null);
		
	}
	
	

	
	
}