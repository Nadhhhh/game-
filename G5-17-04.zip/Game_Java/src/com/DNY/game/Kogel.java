package com.DNY.game;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;

public class Kogel{
	
	ImageIcon icon_kogel;
	Image kogel;

	
	final int Y;         //De wekelijke hoogte van Het beeld van de upgeloade kogel
	final int X;		 //De wekelijke breedte van Het beeld van de upgeloade kogel
	
	public int xk;		//De x-positie van de kogel
	public int yk;		//De y-positie
	 
	
	
	
	public Kogel(Ufo ufo){
		
		this.icon_kogel = new ImageIcon(getClass().getResource("/Images/KogelBlauw2.png"));
		this.kogel = this.icon_kogel.getImage();

		
		this.Y=18;
		this.X=25;
		
		this.xk = ufo.XU + ufo.X;
		this.yk = ufo.yu + (ufo.Y/2)- (this.Y)/2;
		
	}

	
	public void draw(Graphics g) {
		g.drawImage(this.kogel, this.xk, this.yk, null);
		
	}
}
