/**
 * 
 */
/**
 * @author Nadhir
 *
 */
module Game_Java {
	requires java.desktop;
}