package com.DNY.game;

import javax.swing.JFrame;

public class Main {
	
	
	public static final int WIDTH = 1200;     				//breedte van de venster
	public static final int HEIGHT = 600;     				//lengte van de venster    (even lang als de achtergrond)
	
	
	public static void main(String[] args){
		
		JFrame f = new JFrame("DNY");		
		f.setSize(WIDTH,HEIGHT);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   //venster verdwijnt na het drukken op de kruis
        f.setLocationRelativeTo(null);     					//null staat zodat het in het midden staat op mijn pc scherm
        f.setResizable(false); 								// om de dimensies van mijn scherm niet te veranderen
       
        
        Hoofdpaneel paneel = new Hoofdpaneel();
        f.add(paneel);
        f.addKeyListener(paneel);						//Dit zegt ons dat we naar 'ufo' moeten 'luisteren' bij paneel
        
        f.setVisible(true);   								//om het venster 'zichtbaar te maken', ALS LAATST ZETTEN


	} 

}