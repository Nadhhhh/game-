package com.DNY.game;

import java.awt.Graphics;
import java.awt.Image;
import java.util.Random;

import javax.swing.ImageIcon;

public class Rots{
	
	ImageIcon icon_rots;
	Image rots;
	final static int Y_ROTS_BEELD= 533;     							//de werkelijke verticale grootte van het png-beeld van het rots
	final static int X_ROTS_BEELD = 400;									//de werkelijke horizontale grootte van het png-beeld van het rots
	
	
	final int X_AFSTAND;									//de x-afstand tussen 2 opeenvolgende rotsen
	public int x1;											//x1 = de x-coordinaat van rots-koppel-1  (rots-koppel= onderste rots EN bovenste rots)
	public int x2;											//x2 = de x-coordinaat van rots-koppel-2
			
	final int MAX_Y_HOOGTE;   			    				//de maximum hoogte dat de onderste rots kan aannemen
	final int MIN_Y_AFSTAND;								//de maximm afstand tussen de bovenste en onderste rots zodat de ufo toch wel ertussen kan
	
	Random random;
	public final static int AANTAL_ROTSEN= 100000;								//Aantal rotsen-PAREN dat ik wil maken
	public int[][] y_coord_rotsen; 							//Lijst met willekeurige en speelbare y-coordinaten voor de onderste en bovenste rots
	
	
	
	public Rots() {
		
		this.icon_rots = new ImageIcon(getClass().getResource("/Images/rots.png"));
		this.rots = icon_rots.getImage();
		
		
		this.X_AFSTAND = 800;								//de x-afstand tussen 2 opeenvolgende rotsen
		this.x1 = Main.WIDTH;								//x1 = de x-coordinaat van rots-koppel-1  (rots-koppel= onderste rots EN bovenste rots)
		this.x2 = x1 + X_ROTS_BEELD +X_AFSTAND;				//x2 = de x-coordinaat van rots-koppel-2
				
		this.MAX_Y_HOOGTE = Main.HEIGHT/2;   			    //de maximum hoogte dat de onderste rots kan aannemen, WAARDE GELDT WANNEER WE VANAF BENEDEN TELLEN!!!!!!!!
		this.MIN_Y_AFSTAND = Main.HEIGHT/4;					//de maximm afstand tussen de bovenste en onderste rots zodat de ufo toch wel ertussen kan
		
		this.random = new Random();
								
		this.y_coord_rotsen = new int[this.AANTAL_ROTSEN][2];
		
		 y_coordinaten();
	}
	
	
	
	
	//hier worden de y coordinaten van de onderste-en-bovenste rots gemaakt
	public void y_coordinaten() {
		
		int y1=0;											//y1=de y-coordinaat van de onderste rots
		int y2=0;											//y2=de y-coordinaat van de bovenste rots
		
		for(int i=0; i< this.AANTAL_ROTSEN ;i++) {
			
			
			int y1_hoogte_interval=random.nextInt(this.MAX_Y_HOOGTE );
			y1 = (Main.HEIGHT-this.MAX_Y_HOOGTE)+y1_hoogte_interval;
			
			
			int random_hoogte_verschil = random.nextInt(Main.HEIGHT-(Main.HEIGHT-y1+this.MIN_Y_AFSTAND));
			y2= y1-this.MIN_Y_AFSTAND-random_hoogte_verschil-this.Y_ROTS_BEELD;
			
			y_coord_rotsen[i][0]=y1;
		    y_coord_rotsen[i][1]=y2;	
		}	
		
		
	}
	
	
	public int j = 0;
	public int k = 1;
	
	public void draw(Graphics g) {
		
		
		g.drawImage(this.rots, x1,y_coord_rotsen[this.j][0] ,  null);    //de onderste rots van rosts-koppel-1
		g.drawImage(this.rots, x1,y_coord_rotsen[this.j][1] ,  null);	//de bovenste rots van rosts-koppel-2
		
		g.drawImage(this.rots, x2,y_coord_rotsen[this.k][0] ,  null);	//de onderste rots van rosts-koppel-2
		g.drawImage(this.rots, x2,y_coord_rotsen[this.k][1] ,  null);	//de bovenste rots van rosts-koppel-2
		
		
	}
	
	
	

}
